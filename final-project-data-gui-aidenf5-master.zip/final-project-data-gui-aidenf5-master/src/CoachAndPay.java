public class CoachAndPay {
    private String name;
    private int pay;
    public CoachAndPay(String name, int pay)
    {
        this.name = name;
        this.pay = pay;
    }

    public String getName()
    {
        return name;
    }
    public int getPay()
    {
        return pay;
    }
}
